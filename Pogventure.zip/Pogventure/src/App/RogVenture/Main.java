package App.RogVenture;

import App.RogVenture.Entities.Player;
import App.RogVenture.Entities.Projectile.Projectile;
import App.RogVenture.Maps.BaseRoom;
import App.RogVenture.Maps.BaseRoom2;
import Engine.*;
import Engine.Graphics.Buffer;
import Engine.Tiled.MapManager;
import Engine.Utils.Vector2D;

import java.util.ArrayList;

public class Main extends Game {

    public static MapManager mapManager = MapManager.getInstance();
    public static Player player;

    public static ArrayList<Projectile> projectiles;


    @Override
    public void update() {
        if(!mapManager.getCurrentlyLoadMap().loaded) {
            mapManager.getCurrentlyLoadMap().load();
            mapManager.getCurrentlyLoadMap().loaded = true;
        }
        player.update();
        ArrayList<Projectile> newProjectiles = new ArrayList<>();
        for(int i = 0; i < projectiles.size(); i++) {
            projectiles.get(i).update();
            if(!projectiles.get(i).kill) {
                newProjectiles.add(projectiles.get(i));
            }
        }
        projectiles = newProjectiles;

        MapManager.getInstance().getCurrentlyLoadMap().update(player);
    }

    @Override
    public void drawOnBuffer(Buffer buffer) {
        mapManager.getCurrentlyLoadMap().drawLayer(buffer);
        player.draw(buffer);
        mapManager.getCurrentlyLoadMap().postDrawLayer(buffer);
        for(int i = 0; i < projectiles.size(); i++) {
            projectiles.get(i).draw(buffer);
        }
    }

    @Override
    public void initialize() {
        player = new Player(64, 64, new Vector2D(2, 2));
        mapManager.registerMap("BaseMap", new BaseRoom());
        mapManager.registerMap("BaseMap2", new BaseRoom2());
        mapManager.setLoadedMap("BaseMap");

        projectiles = new ArrayList<>();
    }

    @Override
    public void conclude() {

    }
}
