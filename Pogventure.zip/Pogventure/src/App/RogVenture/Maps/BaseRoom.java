package App.RogVenture.Maps;

import App.RogVenture.Main;
import Engine.Entity.EntityType.PlayerEntity;
import Engine.Graphics.Buffer;
import Engine.Tiled.Parser.Layer;
import Engine.Tiled.PhysicalMap;
import Engine.Tiled.WarpPoint;
import Engine.Utils.Vector2D;

public class BaseRoom extends PhysicalMap {
    @Override
    public void load() {
        preGenerateMap();
        warpPoint.add(new WarpPoint(new Vector2D(9, 4), new Vector2D(15, 5), 1, 1, "BaseMap"));
        warpPoint.add(new WarpPoint(new Vector2D(15, 4), new Vector2D(9, 5), 1, 1, "BaseMap"));
        warpPoint.add(new WarpPoint(new Vector2D(33, 1), new Vector2D(1.5f, 30), 2, 1, "BaseMap2"));
        fixedCamera = false;
    }

    @Override
    public void drawLayer(Buffer buffer) {
        for (Layer layer : this.layerList) {
            layer.draw(buffer, Main.player);
        }
    }

    @Override
    public void postDrawLayer(Buffer buffer) {
        for (Layer layer : this.layerList) {
            if(layer.layerName.equals("Fake3D")) {
                layer.draw(buffer, Main.player);
            }
        }
    }

    @Override
    public void preGenerateMap() {
        for (Layer layer : this.layerList) {
            if(!layer.layerName.equals("Permission")) {
                layer.constructImage(textureBuffer);
            }
        }
    }

    @Override
    public void generateCollision() {
        for (Layer layer : this.layerList) {
            if(layer.layerName.equals("Permission")) {
                layer.generateCollision(this.getSpecificTextureID("Permission.tsx"));
            }
        }
    }

    @Override
    public void specialUpdate(PlayerEntity player) {

    }
}
