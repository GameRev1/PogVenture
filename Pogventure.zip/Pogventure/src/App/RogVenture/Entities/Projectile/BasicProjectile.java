package App.RogVenture.Entities.Projectile;

import App.RogVenture.Main;
import Engine.Entity.EntityType.MovableEntity;
import Engine.Graphics.Buffer;
import Engine.Graphics.RenderingEngine;
import Engine.Utils.Vector2D;

import java.awt.*;

public class BasicProjectile extends Projectile {

    public BasicProjectile(MovableEntity owner, Vector2D velocity) {
        this.velocity = velocity;
        this.owner = owner;
        this.position = this.owner.getPosition().Subtract(new Vector2D(owner.width, owner.height));
        this.hostile = false;
        this.friendly = true;
        this.width = 16;
        this.height = 2;
        this.timeLeft = 50;
    }

    @Override
    public void AI() {
        this.position = this.position.Add(this.velocity);
    }

    @Override
    public void cutSprite() {

    }

    @Override
    public void draw(Buffer buffer) {
        Dimension renderingEngineDimension = RenderingEngine.getInstance().getScreenDimension();
        Vector2D drawPosition = new Vector2D((renderingEngineDimension.width / 2 - width), (renderingEngineDimension.height / 2 - height));
        drawPosition = drawPosition.Subtract(this.position);
        buffer.drawRectangle(drawPosition, width, height, Color.green);
    }
}
