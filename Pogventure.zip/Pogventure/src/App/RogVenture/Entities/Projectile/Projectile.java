package App.RogVenture.Entities.Projectile;

import Engine.Entity.EntityType.MovableEntity;
import Engine.Graphics.Buffer;
import Engine.Networking.ArrayListNetwork;

import java.awt.*;
import java.util.Objects;

public abstract class Projectile extends MovableEntity {
    public boolean friendly;
    public boolean hostile;

    public MovableEntity owner;
    public int timeLeft;
    public boolean kill;


    public abstract void AI();

    @Override
    public final void update() {
        AI();
        timeLeft--;
        if(timeLeft <= 0) {
            kill = true;
        }
    }

    @Override
    public Rectangle getBound() {
        return new Rectangle((int)position.x, (int)position.y, width, height);
    }

    @Override
    public void syncData(ArrayListNetwork data) {

    }

    @Override
    public void receiveData(ArrayListNetwork data) {

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Projectile that = (Projectile) o;
        return friendly == that.friendly &&
                hostile == that.hostile &&
                kill == that.kill;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), friendly, hostile, kill);
    }
}
