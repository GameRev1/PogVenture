package App.RogVenture.Entities;

import App.RogVenture.Entities.Projectile.BasicProjectile;
import App.RogVenture.Entities.Projectile.Projectile;
import App.RogVenture.Main;
import Engine.Entity.Camera.Camera;
import Engine.Entity.EntityType.PlayerEntity;
import Engine.Entity.Input.Direction;
import Engine.Entity.Input.PlayerInput;
import Engine.Graphics.Buffer;
import Engine.Graphics.RenderingEngine;
import Engine.Networking.ArrayListNetwork;
import Engine.Tiled.PhysicalMap;
import Engine.Utils.ObjectCaster;
import Engine.Utils.Vector2D;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Vector;

public class Player extends PlayerEntity {

    public Player(float x, float y, Vector2D defaultSpeed) {
        position = new Vector2D(x, y);
        velocity = defaultSpeed;
        camera = new PlayerCamera(this);
        super.setDefaultDimension(16, 16);
        cutSprite();
    }

    @Override
    protected void movePlayer() {
        isMoving = false;
        if (PlayerInput.getInstance().getKeyState(KeyEvent.VK_DOWN)) {
            setPosition(new Vector2D(position.x, position.y + velocity.y));
            this.move(Direction.DOWN);

        }
        if (PlayerInput.getInstance().getKeyState(KeyEvent.VK_UP)) {
            setPosition(new Vector2D(position.x, position.y - velocity.y));
            this.move(Direction.UP);
        }
        if (PlayerInput.getInstance().getKeyState(KeyEvent.VK_LEFT)) {
            setPosition(new Vector2D(position.x - velocity.x, position.y));
            this.move(Direction.LEFT);
        }
        if (PlayerInput.getInstance().getKeyState(KeyEvent.VK_RIGHT)) {
            setPosition(new Vector2D(position.x + velocity.x, position.y));
            this.move(Direction.RIGHT);
        }
        if (PlayerInput.getInstance().getKeyState(KeyEvent.VK_F)){
            Main.projectiles.add(new BasicProjectile(this, new Vector2D(2, 0)));
        }
        //this.velocity = new Vector2D(2, 2);

    }

    @Override
    public void update() {
        movePlayer();
        Dimension mapDimension = Main.mapManager.getCurrentlyLoadMap().getMapDimension();
        camera.update();
        if (position.x <= 0) {
            position.x = 0;
        }
        if (position.y <= 0) {
            position.y = 0;
        }
        if (position.x >= mapDimension.width - width) {
            position.x = mapDimension.width - width;
        }
        if (position.y >= mapDimension.height - height) {
            position.y = mapDimension.height - height;
        }
        if (camera instanceof PlayerCamera) {
            PlayerCamera cam = ObjectCaster.as(camera, PlayerCamera.class);
            cam.resetCamera();
        }
    }

    @Override
    public Rectangle getBound() {
        return new Rectangle(16, 16);
    }

    @Override
    public void cutSprite() {

    }

    @Override
    public void draw(Buffer buffer) {
        if (camera instanceof PlayerCamera) {
            PlayerCamera cam = ObjectCaster.as(camera, PlayerCamera.class);
            cam.resetCamera();
            Dimension renderingEngineDimension = RenderingEngine.getInstance().getScreenDimension();
            Dimension mapDimension = Main.mapManager.getCurrentlyLoadMap().getMapDimension();
            Vector2D drawPosition = new Vector2D((renderingEngineDimension.width / 2 - width), (renderingEngineDimension.height / 2 - height));

            if (Main.mapManager.getCurrentlyLoadMap().fixedCamera) {
                if (position.y < renderingEngineDimension.getHeight() / 2 - getHeight()) {
                    drawPosition.y = position.y;
                    cam.top = true;
                }
                if (position.x < renderingEngineDimension.getWidth() / 2 - getWidth()) {
                    drawPosition.x = position.x;
                    cam.left = true;
                }
                if (position.x > mapDimension.getWidth() - renderingEngineDimension.getWidth() / 2 - getWidth() - 4) {
                    drawPosition.x = position.x - renderingEngineDimension.width / 3.6f;
                    cam.right = true;
                }
                if (position.y > mapDimension.getHeight() - renderingEngineDimension.getHeight() / 2 - getHeight() - 6) {
                    drawPosition.y = position.y - renderingEngineDimension.height / 1.43f;
                    cam.bottom = true;
                }
            }
            buffer.drawRectangle((int) (drawPosition.x + 4), (int) (drawPosition.y - 12), 16, 16, Color.red);
            //buffer.drawScaledTexture(animationSheetOverworld.get(this.getDirection())[animationFrame], (int) (drawPosition.x + 4), (int) (drawPosition.y - 12), 1f);
        }

        buffer.drawScaledText("Camera Position : Vector2D(" + camera.getPositionX() + ", " + camera.getPositionY() + ")", 0, 15, Color.WHITE, 2f);
        buffer.drawScaledText("Player Position : Vector2D(" + position.x + ", " + position.y + ")", 0, 30, Color.WHITE, 2f);
    }

    @Override
    public void syncData(ArrayListNetwork data) {

    }

    @Override
    public void receiveData(ArrayListNetwork data) {

    }

    public class PlayerCamera extends Camera {

        public boolean top = false;
        public boolean bottom = false;
        public boolean left = false;
        public boolean right = false;

        public PlayerCamera(PlayerEntity player) {
            super(player);
        }

        public void resetCamera() {
            top = false;
            bottom = false;
            right = false;
            left = false;
        }

        @Override
        public void update() {
            PhysicalMap currentlyLoadedMap = Main.mapManager.getCurrentlyLoadMap();
            Dimension renderingEngineDimension = RenderingEngine.getInstance().getScreenDimension();
            //position = player.getPosition().Subtract(position);
            //System.out.println("[x: " + position.x + "; y: " + position.y + "]");
            //System.out.println("[width: " + renderingEngineDimension.getWidth() + "; height: " + renderingEngineDimension.getHeight() + "]");

            if (currentlyLoadedMap.fixedCamera) {
                adjustX(renderingEngineDimension, currentlyLoadedMap);
                adjustY(renderingEngineDimension, currentlyLoadedMap);
                return;
            }
            position.x = (float) (800 / 2.1 - player.getPosition().x);
            position.y = (float) (600 / 2.28 - player.getPosition().y);
        }

        private void adjustY(Dimension renderingEngineDimension, PhysicalMap currentlyLoadedMap) {
            if (bottom) {
                this.position.y = -(float) (currentlyLoadedMap.getMapDimension().getHeight() - renderingEngineDimension.getHeight());
                return;
            }
            if (top) {
                this.position.y = 0;
                return;
            }
            if (!top && !bottom) {
                position.y = (float) (currentlyLoadedMap.getMapDimension().getHeight() / 4.05f - player.getPosition().y);
            }
        }

        private void adjustX(Dimension renderingEngineDimension, PhysicalMap currentlyLoadedMap) {
            if (right) {
                this.position.x = -(float) (currentlyLoadedMap.getMapDimension().getWidth() - renderingEngineDimension.getWidth());
                return;
            }
            if (left) {
                this.position.x = 0;
                return;
            }

            if (!left && !right) {
                position.x = (float) (currentlyLoadedMap.getMapDimension().getWidth() / 2.95f - player.getPosition().x);
            }
        }

        public boolean limit() {
            return top || bottom || left || right;
        }
    }

}
