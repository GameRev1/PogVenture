package App.RogVenture.Entities.NPC;

import Engine.Entity.EntityType.MovableEntity;
import Engine.Graphics.Buffer;
import Engine.Networking.ArrayListNetwork;

import java.awt.*;

public abstract class NPC extends MovableEntity {
    @Override
    public void update() {

    }

    @Override
    public Rectangle getBound() {
        return null;
    }

    @Override
    public void cutSprite() {

    }

    @Override
    public void draw(Buffer buffer) {

    }

    @Override
    public void syncData(ArrayListNetwork data) {

    }

    @Override
    public void receiveData(ArrayListNetwork data) {

    }
}
