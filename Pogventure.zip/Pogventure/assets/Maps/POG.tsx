<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="POG" tilewidth="16" tileheight="16" tilecount="703" columns="37">
 <image source="POG.png" width="601" height="316"/>
</tileset>
