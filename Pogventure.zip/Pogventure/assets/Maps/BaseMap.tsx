<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="BaseMap" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="BaseMap.png" width="512" height="512"/>
</tileset>
