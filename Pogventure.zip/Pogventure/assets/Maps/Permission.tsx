<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Permission" tilewidth="16" tileheight="16" tilecount="2" columns="2">
 <image source="Permission.png" width="32" height="16"/>
</tileset>
